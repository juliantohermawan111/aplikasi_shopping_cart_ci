<?php if(!defined('BASEPATH')) exit ('No direct script access allowed');
Class Cart extends CI_Controller {

function __construct()
{
    parent::__construct();
    $this->load->model('product_model','products');
    $this->load->library('cart');
    $this->load->helper('form');
}

function add($id){
        $product = $this->products->get($id);
        $data = array(
           'id' => $product->id,
           'qty' => 1,
           'price' => $product->price,
           'name' => $product->name,
        );

       $this->cart->insert($data);
        redirect("Cart");
}

function update()
{
    $this->cart->update($_POST);
    redirect("Cart");
}

function index() 
{
    $data['cart_list'] = $this->cart->contents();
    $this->load->view('Cart', $data);
}
}
 ?>