<?php if(!defined('BASEPATH')) exit ('No direct script access allowed');

Class Product extends CI_Controller{
	
	function __construct()
	{
		parent::__construct();
	}
	
	//Link...
	function index()
	{
		$this->load->model('Product_model','product');
		$data['product_list'] = $this->product->get_all();
		$this->load->view('product', $data);
	}
}


?>