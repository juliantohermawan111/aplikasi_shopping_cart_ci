<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

Class Product_model extends CI_Model{
	function __construct()
	{
		parent::__construct();
		$this->load->helper('url');

	}
	
	function get_all($limit = NULL, $offset = NULL)
	{
		$query = $this->db->get('products', $limit, $offset);
		return $query->result();
	}
	
	function get($id)
	{
		$query = $this->db->get_where('products', array('id'=>$id));
		return $query->row();
	}
}
?>